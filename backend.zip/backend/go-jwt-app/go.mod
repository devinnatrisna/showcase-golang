module go-jwt-app

go 1.27.1

require github.com/golang-jwt/jwt/v5 v5.3.1 // indirect
